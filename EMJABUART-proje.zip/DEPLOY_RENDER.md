# Render Deploy (Ortak Kayit)

Bu yontemle telefon ve bilgisayar ayni urun kaydini gorur.

## 1) Kodu GitHub'a at

- Bu klasoru bir GitHub repository olarak yukle.

## 2) Render'da yeni servis ac

- https://dashboard.render.com
- New + -> Blueprint
- GitHub repository sec
- `render.yaml` dosyasini otomatik okuyup servis olusturur.

## 3) Environment Variables (zorunlu)

Render servis ayarlarinda su degiskenleri ekleyin:

- `ADMIN_USERNAME` = sizin yonetici kullanici adiniz
- `ADMIN_PASSWORD` = guclu yonetici sifreniz
- `TOKEN_SECRET` = uzun ve rastgele bir metin (en az 32 karakter)
- `TOKEN_TTL_SECONDS` = `43200` (12 saat) veya istediginiz sure
## 4) Acilan linki kullan

- Render size `https://...onrender.com` linki verir.
- Site bu linkte acilir.
- Urun ekleme/silme tum cihazlarda ayni veride gorunur.

## Not

- Free planda servis ilk acilista 30-60 sn gec uyanabilir.
- Gercek kalicilik icin Render Persistent Disk baglamaniz onerilir.
