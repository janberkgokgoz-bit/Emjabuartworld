const ADMIN_CREDENTIALS = {
  username: "Admin",
  password: "Emjabu155635"
};

const STORAGE_KEY = "artisan_products_v1";
const MAX_IMAGE_DIMENSION = 1200;
const IMAGE_QUALITY = 0.82;

const defaultProducts = [
  {
    id: crypto.randomUUID(),
    name: "El Dokuma Kilim",
    price: "2.450 TL",
    imageUrl: "https://images.unsplash.com/photo-1616628182509-6a9d865f5f84?auto=format&fit=crop&w=900&q=80",
    orderLink: "https://example.com/kilim",
    description: "Dogal ipliklerden uretilmis geleneksel desenli kilim."
  },
  {
    id: crypto.randomUUID(),
    name: "Seramik Vazo",
    price: "980 TL",
    imageUrl: "https://images.unsplash.com/photo-1577083552431-6e5fd01988f6?auto=format&fit=crop&w=900&q=80",
    orderLink: "https://example.com/seramik-vazo",
    description: "El yapimi, rustik dokulu dekoratif seramik vazo."
  }
];

let products = loadProducts();
let isAdminLoggedIn = false;
let editingId = null;

const ui = {
  adminToggleBtn: document.getElementById("adminToggleBtn"),
  adminPanel: document.getElementById("adminPanel"),
  loginModal: document.getElementById("loginModal"),
  closeLoginBtn: document.getElementById("closeLoginBtn"),
  loginForm: document.getElementById("loginForm"),
  loginError: document.getElementById("loginError"),
  logoutBtn: document.getElementById("logoutBtn"),
  productForm: document.getElementById("productForm"),
  productId: document.getElementById("productId"),
  name: document.getElementById("name"),
  price: document.getElementById("price"),
  imageFile: document.getElementById("imageFile"),
  orderLink: document.getElementById("orderLink"),
  description: document.getElementById("description"),
  cancelEditBtn: document.getElementById("cancelEditBtn"),
  saveStatus: document.getElementById("saveStatus"),
  searchInput: document.getElementById("searchInput"),
  productList: document.getElementById("productList"),
  emptyState: document.getElementById("emptyState"),
  imageModal: document.getElementById("imageModal"),
  zoomedImage: document.getElementById("zoomedImage"),
  closeImageBtn: document.getElementById("closeImageBtn")
};

function loadProducts() {
  let raw = null;
  try {
    raw = localStorage.getItem(STORAGE_KEY);
  } catch {
    return [...defaultProducts];
  }

  if (!raw) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(defaultProducts));
    } catch {
      // Tarayici depolamasi yazilamazsa sadece varsayilanlari RAM'de kullan.
    }
    return defaultProducts;
  }

  try {
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) {
      return parsed;
    }
    localStorage.setItem(STORAGE_KEY, JSON.stringify(defaultProducts));
    return defaultProducts;
  } catch {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(defaultProducts));
    return defaultProducts;
  }
}

function saveProducts() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(products));
    return true;
  } catch {
    return false;
  }
}

function showSaveStatus(message) {
  ui.saveStatus.textContent = message;
  ui.saveStatus.classList.remove("hidden");
  clearTimeout(showSaveStatus.timeoutId);
  showSaveStatus.timeoutId = setTimeout(() => {
    ui.saveStatus.classList.add("hidden");
  }, 1800);
}

function setAdminMode(value) {
  isAdminLoggedIn = value;
  ui.adminPanel.classList.toggle("hidden", !value);
  ui.adminToggleBtn.textContent = value ? "Yonetici Aktif" : "Yonetici Girisi";
  renderProducts();
}

function openLoginModal() {
  ui.loginModal.classList.remove("hidden");
  ui.loginModal.setAttribute("aria-hidden", "false");
  ui.loginError.classList.add("hidden");
  ui.loginForm.reset();
}

function closeLoginModal() {
  ui.loginModal.classList.add("hidden");
  ui.loginModal.setAttribute("aria-hidden", "true");
}

function resetForm() {
  editingId = null;
  ui.productForm.reset();
  ui.cancelEditBtn.classList.add("hidden");
}

function fillForm(product) {
  editingId = product.id;
  ui.name.value = product.name;
  ui.price.value = product.price;
  ui.imageFile.value = "";
  ui.orderLink.value = product.orderLink;
  ui.description.value = product.description;
  ui.cancelEditBtn.classList.remove("hidden");
}

function readFileAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error("Gorsel dosyasi okunamadi."));
    reader.readAsDataURL(file);
  });
}

function optimizeImageDataUrl(dataUrl) {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => {
      const ratio = Math.min(
        1,
        MAX_IMAGE_DIMENSION / image.width,
        MAX_IMAGE_DIMENSION / image.height
      );
      const targetWidth = Math.max(1, Math.round(image.width * ratio));
      const targetHeight = Math.max(1, Math.round(image.height * ratio));
      const canvas = document.createElement("canvas");
      canvas.width = targetWidth;
      canvas.height = targetHeight;
      const context = canvas.getContext("2d");

      if (!context) {
        reject(new Error("Canvas context olusturulamadi."));
        return;
      }

      context.drawImage(image, 0, 0, targetWidth, targetHeight);
      resolve(canvas.toDataURL("image/jpeg", IMAGE_QUALITY));
    };
    image.onerror = () => reject(new Error("Gorsel islenemedi."));
    image.src = dataUrl;
  });
}

async function readAndOptimizeImage(file) {
  const rawDataUrl = await readFileAsDataUrl(file);
  if (!String(rawDataUrl).startsWith("data:image/")) {
    return rawDataUrl;
  }
  return optimizeImageDataUrl(rawDataUrl);
}

function createCard(product) {
  const card = document.createElement("article");
  card.className = "card";

  const image = document.createElement("img");
  image.src = product.imageUrl;
  image.alt = product.name;
  image.addEventListener("click", () => openImage(product.imageUrl, product.name));

  const content = document.createElement("div");
  content.className = "card-content";

  const name = document.createElement("h3");
  name.textContent = product.name;

  const price = document.createElement("p");
  price.className = "price";
  price.textContent = product.price;

  const desc = document.createElement("p");
  desc.className = "desc";
  desc.textContent = product.description || "";

  const actions = document.createElement("div");
  actions.className = "card-actions";

  const orderLink = document.createElement("a");
  orderLink.className = "order-link";
  orderLink.href = product.orderLink;
  orderLink.target = "_blank";
  orderLink.rel = "noopener noreferrer";

  const orderButton = document.createElement("button");
  orderButton.type = "button";
  orderButton.textContent = "Siparis icin tiklayiniz";
  orderLink.appendChild(orderButton);
  actions.appendChild(orderLink);

  if (isAdminLoggedIn) {
    const editButton = document.createElement("button");
    editButton.type = "button";
    editButton.className = "secondary";
    editButton.textContent = "Duzenle";
    editButton.addEventListener("click", () => fillForm(product));

    const deleteButton = document.createElement("button");
    deleteButton.type = "button";
    deleteButton.className = "secondary";
    deleteButton.textContent = "Sil";
    deleteButton.addEventListener("click", () => {
      products = products.filter((item) => item.id !== product.id);
      const saved = saveProducts();
      if (!saved) {
        alert("Degisiklik kaydedilemedi. Tarayici depolama alani dolu olabilir.");
        return;
      }
      showSaveStatus("Urun silindi ve kaydedildi.");
      renderProducts(ui.searchInput.value);
      if (editingId === product.id) {
        resetForm();
      }
    });

    actions.append(editButton, deleteButton);
  }

  content.append(name, price, desc, actions);
  card.append(image, content);
  return card;
}

function renderProducts(searchText = "") {
  const term = searchText.trim().toLowerCase();
  const filtered = products.filter((product) => {
    const haystack = `${product.name} ${product.price} ${product.description}`.toLowerCase();
    return haystack.includes(term);
  });

  ui.productList.innerHTML = "";
  filtered.forEach((product) => {
    ui.productList.appendChild(createCard(product));
  });

  ui.emptyState.classList.toggle("hidden", filtered.length > 0);
}

function openImage(src, alt) {
  ui.zoomedImage.src = src;
  ui.zoomedImage.alt = alt;
  ui.imageModal.classList.remove("hidden");
  ui.imageModal.setAttribute("aria-hidden", "false");
}

function closeImage() {
  ui.imageModal.classList.add("hidden");
  ui.imageModal.setAttribute("aria-hidden", "true");
  ui.zoomedImage.src = "";
}

ui.adminToggleBtn.addEventListener("click", () => {
  if (isAdminLoggedIn) {
    return;
  }
  openLoginModal();
});

ui.closeLoginBtn.addEventListener("click", closeLoginModal);

ui.loginForm.addEventListener("submit", (event) => {
  event.preventDefault();

  const username = document.getElementById("adminUsername").value.trim();
  const password = document.getElementById("adminPassword").value;

  if (
    username === ADMIN_CREDENTIALS.username &&
    password === ADMIN_CREDENTIALS.password
  ) {
    setAdminMode(true);
    closeLoginModal();
    showSaveStatus("Yonetici girisi basarili.");
    return;
  }

  ui.loginError.classList.remove("hidden");
});

ui.logoutBtn.addEventListener("click", () => {
  setAdminMode(false);
  resetForm();
});

ui.productForm.addEventListener("submit", async (event) => {
  event.preventDefault();

  const selectedFile = ui.imageFile.files[0];
  let imageUrl = "";

  if (selectedFile) {
    try {
      imageUrl = await readAndOptimizeImage(selectedFile);
    } catch {
      alert("Fotograf okunurken bir hata olustu. Lutfen tekrar deneyin.");
      return;
    }
  } else if (editingId) {
    const currentProduct = products.find((item) => item.id === editingId);
    imageUrl = currentProduct ? currentProduct.imageUrl : "";
  } else {
    alert("Lutfen urun icin bir fotograf secin.");
    return;
  }

  const product = {
    id: editingId || crypto.randomUUID(),
    name: ui.name.value.trim(),
    price: ui.price.value.trim(),
    imageUrl,
    orderLink: ui.orderLink.value.trim(),
    description: ui.description.value.trim()
  };

  if (editingId) {
    products = products.map((item) => (item.id === editingId ? product : item));
    showSaveStatus("Urun guncellendi ve kaydedildi.");
  } else {
    products.unshift(product);
    showSaveStatus("Yeni urun eklendi ve kaydedildi.");
  }

  const saved = saveProducts();
  if (!saved) {
    alert("Degisiklik kaydedilemedi. Tarayici depolama alani dolu olabilir.");
    return;
  }
  resetForm();
  renderProducts(ui.searchInput.value);
});

ui.cancelEditBtn.addEventListener("click", resetForm);

ui.searchInput.addEventListener("input", (event) => {
  renderProducts(event.target.value);
});

ui.closeImageBtn.addEventListener("click", closeImage);
ui.imageModal.addEventListener("click", (event) => {
  if (event.target === ui.imageModal) {
    closeImage();
  }
});

renderProducts();
